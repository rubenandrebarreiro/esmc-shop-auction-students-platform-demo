<html>
	<head>
		<title>ESMC Shop - Aqui s&oacute n&atildeo encontra o que n&atildeo quer!</title>
	</head>
	<body>
		<?php
			if (!isset($_SESSION))
			{
				Session_start();
				$id_artigo=$_GET["id_artigo"];
				$lig=mysql_connect("localhost","root","") or die ("Erro na conex�o");
				mysql_select_db("esmc_shop",$lig) or die ("Erro na escolha da Base de Dados (ESMC Shop)");
				$query="delete from artigos where id_artigo='$id_artigo'";
				$res=mysql_query($query);
				Session_destroy();
				include("main_apagar_artigo.php");	
			}
			else
			{
				$id_artigo=$_GET["id_artigo"];
				$lig=mysql_connect("localhost","root","") or die ("Erro na conex�o");
				mysql_select_db("esmc_shop",$lig) or die ("Erro na escolha da Base de Dados (ESMC Shop)");
				$query="delete from artigos where id_artigo='$id_artigo'";
				$res=mysql_query($query);
				Session_destroy();
				include("main_apagar_artigo.php");	
			}
		?>
	</body>
</html>