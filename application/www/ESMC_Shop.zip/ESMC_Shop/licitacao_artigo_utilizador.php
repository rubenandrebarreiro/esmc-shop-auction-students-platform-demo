<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<meta name="description" content="ESMC Shop">
		<meta name="keywords" content="ESMC Shop">
		<title>ESMC Shop - Aqui s&oacute n&atildeo encontra o que n&atildeo quer!</title>
		<link href="http://fonts.googleapis.com/css?family=Coda+Caption" rel="stylesheet" type="text/css">
		<link href="http://fonts.googleapis.com/css?family=Jura" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<script language="javascript">
		function test_registo_artigos()
		{
			chck1=false;
			chck2=false;			
			if (form_registo_artigos.nome_artigo.value.length == 0)
			{
				alert ("Tem que preencher o campo NOME DO ARTIGO");
				return false;
			}
			if (form_registo_artigos.nome_artigo.value.length < 2)
			{
				alert ("O campo NOME DO ARTIGO deve ter mais do que 1 caracter");
				return false;
			}
			if (form_registo_artigos.nome_artigo.value.length > 26)
			{
				alert ("O campo NOME DO ARTIGO n�o deve ter mais do que 26 caracteres");
				return false;
			}
			if (form_registo_artigos.foto_artigo.value.length == 0)
			{
				alert ("Tem que seleccionar uma foto para ser a FOTO DO ARTIGO");
				return false;
			}
			if (form_registo_artigos.descricao_artigo.value.length == 0)
			{
				alert ("Tem que preencher o campo DESCRI��O DO ARTIGO");
				return false;
			}
			if (form_registo_artigos.descricao_artigo.value.length < 8)
			{
				alert ("O campo DESCRI��O DO ARTIGO deve ter mais do que 7 caracteres");
				return false;
			}
			if (form_registo_artigos.descricao_artigo.value.length > 60)
			{
				alert ("O campo DESCRI��O DO ARTIGO n�o deve ter mais do que 60 caracteres");
				return false;
			}
			for (i=0; i < document.form_registo_artigos.condicao_artigo_escolha.length; i++)
			{
				if (document.form_registo_artigos.condicao_artigo_escolha[i].checked == true)
				{
					chck1=true;
					break;
				}
			}
			if (chck1==false)
			{
					alert ("Tem de seleccionar uma CONDI��O DO ARTIGO (Novo/Usado)"); 
					return false;
			}
			if ((form_registo_artigos.hora_limite_hh.selectIndex == 0) || (form_registo_artigos.hora_limite_mm.selectIndex == 0) || (form_registo_artigos.data_limite_dd.selectIndex == 0) || (form_registo_artigos.data_limite_mm.selectedIndex == 0) || (form_registo_artigo.data_limite_aaaa.selectedIndex == 0))
			{
				alert ("Tem que seleccionar uma HORA E DATA LIMITE DO LEIL�O");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 2) && (form_registo_artigos.data_limite_dd.value == 30))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 2) && (form_registo_artigos.data_limite_dd.value == 31))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 4) && (form_registo_artigos.data_limite_dd.value == 31))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 6) && (form_registo_artigos.data_limite_dd.value == 31))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 9) && (form_registo_artigos.data_limite_dd.value == 31))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.data_limite_mm.value == 11) && (form_registo_artigos.data_limite_dd.value == 31))
			{
				alert ("O campo HORA E DATA LIMITE DO LEIL�O est� inv�lido");
				return false;
			}
			if ((form_registo_artigos.licitacao_base_ee.value.length == 0) || (form_registo_artigos.licitacao_base_cc.value.length == 0))
			{
				alert ("Tem que preencher o campo LICITA��O BASE OU PRE�O INICIAL");
				return false;
			}
			if (form_registo_artigos.licitacao_base_cc.value.length > 2)
			{
				alert ("O campo LICITA��O BASE OU PRE�O INICIAL est� inv�lido");
				return false;
			}
			if ((isNaN(document.form_registo_artigos.licitacao_base_ee.value) == true) || (isNaN(document.form_registo_artigos.licitacao_base_cc.value) == true))
			{
				alert ("Tem que preencher o campo LICITA��O BASE OU PRE�O INICIAL apenas com caracteres num�ricos");
				return false;
			}
			if ((form_registo_artigos.preco_final_ee.value.length == 0) || (form_registo_artigos.preco_final_cc.value.length == 0))
			{
				alert ("Tem que preencher o campo PRE�O FINAL");
				return false;
			}
			if (form_registo_artigos.preco_final_cc.value.length > 2)
			{
				alert ("O campo PRE�O FINAL est� inv�lido");
				return false;
			}
			if ((isNaN(document.form_registo_artigos.preco_final_ee.value) == true) || (isNaN(document.form_registo_artigos.preco_final_cc.value) == true))
			{
				alert ("Tem que preencher o campo PRE�O FINAL apenas com caracteres num�ricos");
				return false;
			}
			if ((form_registo_artigos.custos_envio_ee.value.length == 0) || (form_registo_artigos.custos_envio_cc.value.length == 0))
			{
				alert ("Tem que preencher o campo CUSTOS DE ENVIO");
				return false;
			}
			if (form_registo_artigos.custos_envio_cc.value.length > 2)
			{
				alert ("O campo CUSTOS DE ENVIO est� inv�lido");
				return false;
			}
			if ((isNaN(document.form_registo_artigos.custos_envio_ee.value) == true) || (isNaN(document.form_registo_artigos.custos_envio_cc.value) == true))
			{
				alert ("Tem que preencher o campo CUSTOS DE ENVIO apenas com caracteres num�ricos");
				return false;
			}
			for (ii=0; ii < document.form_registo_artigos.forma_pagamento_escolha.length; ii++)
			{
				if (document.form_registo_artigos.forma_pagamento_escolha[ii].checked == true)
				{
					chck2=true;
					break;
				}
			}
			if (chck2==false)
			{
					alert ("Tem de seleccionar uma FORMA DE PAGAMENTO (Dinheiro/Multibanco)"); 
					return false;
			}
			if (form_registo_artigos.categorias.selectedIndex == 0)
			{
				alert ("Tem que seleccionar uma CATEGORIA");
				return false;
			}
			return true;
		}
    </script>
    <body>
		<?php
			if (!isset($_SESSION))
			{
				Session_start();
			}
			$id_artigo=$_GET["id_artigo"];
			$lig=mysql_connect("localhost","root","") or die("Erro na conex�o");
			mysql_select_db("esmc_shop",$lig) or die("Erro na escolha da Base de Dados (ESMC Shop)");
			$query1 = "SELECT * from utilizadores where nome_utilizador='" . $_SESSION["nome_utilizador"] . "'";
			$res1=mysql_query($query1);
			$row1 = mysql_fetch_array($res1);
			$query2 = "SELECT * from artigos, utilizadores, categorias where artigos.id_artigo='$id_artigo' and artigos.nome_utilizador = utilizadores.nome_utilizador and artigos.id_categoria=categorias.id_categoria";
			$res2=mysql_query($query2);
			$row2 = mysql_fetch_array($res2);
		?>
		<?php
			if (date("l")=="Sunday")
			{
				$dia_sem_actual="Domingo";
			}
			if (date("l")=="Monday")
			{
				$dia_sem_actual="Segunda-Feira";
			}
			if (date("l")=="Tuesday")
			{
				$dia_sem_actual="Ter�a-Feira";
			}
			if (date("l")=="Wednesday")
			{
				$dia_sem_actual="Quarta-Feira";
			}
			if (date("l")=="Thursday")
			{
				$dia_sem_actual="Quinta-Feira";
			}
			if (date("l")=="Friday")
			{
				$dia_sem_actual="Sexta-Feira";
			}
			if (date("l")=="Saturday")
			{
				$dia_sem_actual="S�bado";
			}
			$dia_mes_actual=date("d");
			if (date("F")=="January")
			{
				$mes_actual="Janeiro";
			}
			if (date("F")=="February")
			{
				$mes_actual="Fevereiro";
			}
			if (date("F")=="March")
			{
				$mes_actual="Mar�o";
			}
			if (date("F")=="April")
			{
				$mes_actual="Abril";
			}
			if (date("F")=="May")
			{
				$mes_actual="Maio";
			}
			if (date("F")=="June")
			{
				$mes_actual="Junho";
			}
			if (date("F")=="July")
			{
				$mes_actual="Julho";
			}
			if (date("F")=="August")
			{
				$mes_actual="Agosto";
			}
			if (date("F")=="September")
			{
				$mes_actual="Setembro";
			}
			if (date("F")=="October")
			{
				$mes_actual="Outubro";
			}
			if (date("F")=="November")
			{
				$mes_actual="Novembro";
			}
			if (date("F")=="December")
			{
				$mes_actual="Dezembro";
			}
			$ano_actual=date("Y");
			$hora_actual=date("H");
			$minuto_actual=date("i");
			$data_hora_hoje = date("d/m/Y - H:i");
			$hora_limite = explode (':', $row2["hora_limite"]);
			$hora_limite_hh = $hora_limite[0];
			$hora_limite_mm = $hora_limite[1];
			$data_limite = explode ('-', $row2["data_limite"]);
			$data_limite_dd = $data_limite[2];
			$data_limite_mm = $data_limite[1];
			$data_limite_aaaa = $data_limite[0];
			$preco_final = explode ('.', $row2["preco_final"]);
			$preco_final_ee = $preco_final[0];
			$preco_final_cc = $preco_final[1];
			$custos_envio = explode ('.', $row2["custos_envio"]);
			$custos_envio_ee = $custos_envio[0];
			$custos_envio_cc = $custos_envio[1];
		?>
		<div id="outer">
			<div id="header">
				<div id="logo">
					<a href="index.html"><img src="images/logo.png" alt="ESMC Shop"></a>
				</div>
				<div id="nav">
					<ul>
						<li class="first">
							<a href="index.html">In&iacutecio</a>
						</li>
						<li>
							<a href="#">Pesquisa Avan&ccedilada</a>
						</li>
						<li>
							<a href="#">Sobre N&oacutes</a>
						</li>
						<li class="last">
							<a href="contactos.html">Contactos e Links</a>
						</li>
					</ul>
				</div>
			</div>
			<div id="banner">
				<img src="images/pic01.jpg" width="1180" height="305" alt="Escola Secund&aacuteria do Monte da Caparica">
			</div>
			<div id="main">
				<div id="content">
					<div id="box1">
						<div class="blogpost primary_wide2">
							<h2>Pesquisa R&aacutepida</h2>
							<form name="quick_search" method="POST" action="#">
								<input type="text" maxlength="100" size="" class="inputBox_search" name="search_text">
								&nbsp;
								<select name="seleccao_pesquisa_index_categorias" class="inputBox_search" id="select_category">
									<option value="none" selected="selected">Todas as Categorias</option>
									<option value="Animais">Animais</option>
									<option value="Antiguidades">Antiguidades</option>
									<option value="Calcado">Cal&ccedilado</option>
									<option value="Computadores e Materiais Informaticos">Computadores e Materiais Inform&aacuteticos</option>
									<option value="Consolas e Jogos">Consolas e Jogos</option>
									<option value="Fotografia e Video">Fotografia e V&iacutedeo</option>
									<option value="Livros de Literatura">Livros de Literatura</option>
									<option value="Livros Escolares">Livros Escolares</option>
									<option value="Musica">M&uacutesica</option>
									<option value="Produtos Artisticos">Produtos Art&iacutesticos</option>
									<option value="Telemoveis">Telem&oacuteveis</option>
									<option value="Vestuario">Vestu&aacuterio</option>
								</select>
								&nbsp;
								<input type="button" name="search_button" value="Pesquisar" class="inputButton_search">
							</form>
							<br>
						</div>
					</div>
					<div id="box4">
						<h3>Aqui pode fazer a licita&ccedil;&atilde;o pelo artigo que deseja ou pagar o seu pre&ccedil;o final para o adquirir</h3>
						<ul class='sectionList'>
							<?php
								$hora_actual_hh=date("H");
								$hora_actual_mm=date("i");
								$hora_actual_ss=date("s");
								$hora_actual_comp=$hora_actual_hh . $hora_actual_mm . $hora_actual_ss;
								$data_actual_dd=date("d");
								$data_actual_mm=date("m");
								$data_actual_aaaa=date("Y");
								$data_actual_comp=$data_actual_aaaa . $data_actual_mm . $data_actual_dd;
								$data_hora_actual_comp=$data_actual_comp . $hora_actual_comp;
								$hora_limite = explode (':', $row2["hora_limite"]);
								$hora_limite_hh =$hora_limite[0];
								$hora_limite_mm =$hora_limite[1];
								$hora_limite_ss =$hora_limite[2];
								$data_limite = explode ('-', $row2["data_limite"]);
								$data_limite_dd =$data_limite[2];
								$data_limite_mm =$data_limite[1];
								$data_limite_aaaa =$data_limite[0];
								$hora_limite_comp=$hora_limite_hh . $hora_limite_mm . $hora_limite_ss;
								$data_limite_comp=$data_limite_aaaa . $data_limite_mm . $data_limite_dd;									
								$data_hora_limite_comp=$data_limite_comp . $hora_limite_comp;
								$licitacao_base = explode ('.', $row2["licitacao_base"]);
								$licitacao_base_ee = $licitacao_base[0];
								$licitacao_base_cc = $licitacao_base[1];
								$query3 = "SELECT * from licitacoes, artigos, utilizadores where licitacoes.id_artigo='" . $row2["id_artigo"] . "' and licitacoes.id_artigo=artigos.id_artigo and licitacoes.nome_utilizador=utilizadores.nome_utilizador and licitacoes.valor_licitacao=(select max(valor_licitacao) from licitacoes)";
								$res3=mysql_query($query3);
								$num_rows3 = mysql_num_rows($res3);
								$preco_final = explode ('.', $row2["preco_final"]);
								$preco_final_ee = $preco_final[0];
								$preco_final_cc = $preco_final[1];
								$custos_envio = explode ('.', $row2["custos_envio"]);
								$custos_envio_ee = $custos_envio[0];
								$custos_envio_cc = $custos_envio[1];
							?>
							<li>
							<form name='form_licitacao_artigos' method='post' action='processar_licitacao_artigos.php' onSubmit='return test_licitacao_artigos();'>
								<?php
									echo "<h4>" . $row2['nome_artigo'] . "</h4>";
									echo "<img class='left' src='./imgs_leilao/" . $row2['foto_artigo'] . "' width='75' height='75'>";
									echo "<b>Descri&ccedil;&atilde;o do Artigo:</b>&nbsp;<i>" . $row2['descricao_artigo'] . "</i>";
									echo "<br>";
									echo "<b>Condi&ccedil;&atilde;o do Artigo:</b>&nbsp;" . $row2['condicao_artigo'];
									echo "<br>";
									if ($data_hora_limite_comp > $data_hora_actual_comp)
									{
										echo "<b>Estado do Leil&atilde;o:</b>&nbsp;A Decorrer";
									}
									if ($data_hora_limite_comp <= $data_hora_actual_comp)
									{
										echo "<b>Estado do Leil&atilde;o:</b>&nbsp;Terminado";
									}
									echo "<br>";
									echo "<b>Hora Limite do Leil&atilde;o:</b>&nbsp;" . $hora_limite_hh . ":" . $hora_limite_mm;
									echo "<br>";
									echo "<b>Data Limite do Leil&atilde;o:</b>&nbsp;" . $data_limite_dd . "/" . $data_limite_mm . "/" . $data_limite_aaaa;
									echo "<br>";
									echo "<br>";
									if (mysql_num_rows($res3) == 1)
									{
										$row3 = mysql_fetch_array ($res3);
										$licitacao_actual = explode ('.', $row3["valor_licitacao"]);
										$licitacao_actual_ee = $licitacao_actual[0];
										$licitacao_actual_cc = $licitacao_actual[1];
										echo "<p>";
											echo "<label for='valor_licitacao' class='signup'><b>Introduza o valor da sua Licita&ccedil;&atilde;o</b></label>";
											echo "<input type='text' class='inputBox5' name='valor_licitacao_ee'>&nbsp;&nbsp;,&nbsp;&nbsp;<input type='text' class='inputBox6' name='valor_licitacao_cc'>&nbsp;&nbsp;&euro;";
											echo "<br>";
											echo "<font id='sugestoes'>O valor da sua licita&ccedil;&atilde;o deve ser superior a " . $licitacao_actual_ee . "," . $licitacao_actual_cc . "&euro;";
										echo "</p>";
									}
									if (mysql_num_rows($res3) == 0)
									{
										echo "<p>";
											echo "<label for='valor_licitacao' class='signup'><b>Introduza o valor da sua Licita&ccedil;&atilde;o</b></label>";
											echo "<input type='text' class='inputBox5' name='valor_licitacao_ee'>&nbsp;&nbsp;,&nbsp;&nbsp;<input type='text' class='inputBox6' name='valor_licitacao_cc'>&nbsp;&nbsp;&euro;";
											echo "<br>";
											echo "<font id='sugestoes'>O valor da sua licita&ccedil;&atilde;o deve ser superior a " . $licitacao_base_ee . "," . $licitacao_base_cc . "&euro;</font>";
										echo "</p>";
									}
									echo "<b>Pre&ccedil;o Final:</b>&nbsp;" . $preco_final_ee . "," . $preco_final_cc . "&euro;";
									echo "<br>";
									echo "<b>Custos de Envio:</b>&nbsp;" . $custos_envio_ee . "," . $custos_envio_cc . "&euro;";
									echo "<br>";
									echo "<b>Forma de Pagamento:</b>&nbsp;" . $row2['forma_pagamento'];
									echo "<br>";
									echo "<b>Categoria:</b>&nbsp;" . $row2['nome_categoria'];
									echo "<br>";
									$data_cont_aaaa = $data_limite_aaaa - $data_actual_aaaa;
									$data_cont_mm = $data_limite_mm - $data_actual_mm;
									$data_cont_dd = $data_limite_dd - $data_actual_dd;
									$hora_cont_hh = $hora_limite_hh - $hora_actual_hh;
									$hora_cont_mm = $hora_limite_mm - $hora_actual_mm;
									if ($data_cont_mm == 1)
									{
										echo "<font id='sugestoes'>Faltam " . $data_cont_aaaa . " ano(s), " . $data_cont_mm . " m&ecirc;s, " . $data_cont_dd . " dia(s), " . $hora_cont_hh . " hora(s) e " . $hora_cont_mm . " minuto(s) para terminar este leil&atilde;o</font>";
									}
									else
									{
										echo "<font id='sugestoes'>Faltam " . $data_cont_aaaa . " ano(s), " . $data_cont_mm . " meses, " . $data_cont_dd . " dia(s), " . $hora_cont_hh . " hora(s) e " . $hora_cont_mm . " minuto(s) para terminar este leil&atilde;o</font>";
									}
								?>
							</form>
							</li>
						</ul>
					</div>
				</div>
				<div id="sidebar">
					<?php
					echo "<h3>Bem-vindo, <i>" . $_SESSION["nome_utilizador"] . "</i></h3>";
					echo "<h3> O meu menu </h3>";
					?>
					<div class="form">
						<?php
						echo "<p>";
						echo "<li type=square><a href='registo_artigos.php'>Adicionar artigos</a></li>";
						echo "</p>";
						echo "<p>";
						echo "<li type=square><a href='consultar_artigos_utilizador.php?nome_utilizador=" . $row1['nome_utilizador'] . "'>Consultar os meus artigos</a></li>";
						echo "</p>";
						echo "<p>";
						echo "<li type=square><a href=''>Pesquisar Artigos</a></li>";
						echo "</p>";
						echo "<p>";
						echo "<li type=square><a href='actualiza_registo.php?nome_utilizador=" . $row1['nome_utilizador'] . "'>Alterar os meus dados</a></li>";
						echo "</p>";
						echo "<p>";
						echo "<li type=square><a href='cancelar_conta.php'>Cancelar conta</a></li>";
						echo "</p>";
						echo "<p>";
						echo "<li type=square><a href='processar_logout.php'>Sair</a></li>";
						echo "</p>";
						?>
					</div>
				</div>
				<br class="clear">
			</div>
		</div>
		<div id="copyright">
			ESMC Shop by <i>R&uacuteben Barreiro</i> for <a href="http://www.esec-monte-caparica.com/esec/">Escola Secund&aacuteria do Monte de Caparica</a>
		</div>	
</body>
</html>