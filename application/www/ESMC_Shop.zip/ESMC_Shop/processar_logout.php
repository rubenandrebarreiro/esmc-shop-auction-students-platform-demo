<html>
	<head>
		<title>ESMC Shop - Aqui s&oacute n&atildeo encontra o que n&atildeo quer!</title>
	</head>
	<body>
		<?php
			if (!isset($_SESSION))
			{
				session_start();
				session_destroy();
				include("index.html");	
			}
			else
			{
				session_destroy();
				include("index.html");
			}
		?>
	</body>
</html>