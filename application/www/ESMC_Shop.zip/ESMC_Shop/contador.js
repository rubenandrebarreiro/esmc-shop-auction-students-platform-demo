<script language="JavaScript">
	TargetData = form_consultar_artigos.data_limite.value() + " " + form_consultar_artigos.hora_limite.value();
	BackColor = "palegreen";
	ForeColor = "navy";
	CountActive = true;
	CountStepper = -1;
	LeadingZero = true;
	DisplayFormat = "Faltam %%D%% Dia(s), %%H%% Horas(s), %%M%% Minuto(s), %%S%% Segundo(s)";
	FinishMessage = "Este leil�o j� terminou";
</script>